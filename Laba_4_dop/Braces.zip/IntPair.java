public class IntPair
{
    public Integer first;
    public Integer second;

    public IntPair(Integer f, Integer s)
    {
        first = f;
        second = s;
    }
}
